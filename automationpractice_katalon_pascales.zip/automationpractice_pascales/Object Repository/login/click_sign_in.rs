<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>click_sign_in</name>
   <tag></tag>
   <elementGuidId>d1c3f258-6b32-4a1e-b89b-5885bf5c6f46</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Sign in')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.login</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
