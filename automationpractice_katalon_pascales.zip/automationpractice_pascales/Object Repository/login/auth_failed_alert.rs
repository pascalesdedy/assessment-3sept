<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>auth_failed_alert</name>
   <tag></tag>
   <elementGuidId>ab381de3-f040-4824-86f2-aa5cd6ab8c3d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='center_column']/div/ol/li</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>css=div.alert.alert-danger > p</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
