import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('http://automationpractice.com/index.php?controller=authentication&back=my-account')

WebUI.waitForPageLoad(2)

WebUI.sendKeys(findTestObject('login/email_create_field'), 'dedy101@dedy.com')

WebUI.click(findTestObject('login/create_acc_btn'))

WebUI.click(findTestObject('register/radio_mr_reg'))

WebUI.sendKeys(findTestObject('register/first_name_reg'), 'dedya')

WebUI.sendKeys(findTestObject('register/last_name_reg'), 'testa')

WebUI.sendKeys(findTestObject('register/passwd_reg'), '123456')

WebUI.selectOptionByValue(findTestObject('register/drop_days_reg'), '1', true)

WebUI.selectOptionByValue(findTestObject('register/drop_month_reg'), '1', true)

WebUI.selectOptionByValue(findTestObject('register/drop_year_reg'), '1990', true)

WebUI.click(findTestObject('register/checkbox_newsletter_reg'))

WebUI.click(findTestObject('register/checkbox_optin_reg'))

WebUI.sendKeys(findTestObject('register/firstname_ship_reg'), 'dedya')

WebUI.sendKeys(findTestObject('register/lastname_ship_reg'), 'testa')

WebUI.sendKeys(findTestObject('register/company_reg'), 'companyku')

WebUI.sendKeys(findTestObject('register/addr1_reg'), 'jl mawar 352')

WebUI.sendKeys(findTestObject('register/addr2_reg'), 'Depok - Sleman')

WebUI.sendKeys(findTestObject('register/city_reg'), 'Yogyakarta')

WebUI.selectOptionByValue(findTestObject('register/state_reg'), '7', true)

WebUI.sendKeys(findTestObject('register/postcode_reg'), '90210')

WebUI.selectOptionByValue(findTestObject('register/country_reg'), '21', true)

WebUI.sendKeys(findTestObject('register/addinfo_reg'), 'Now adding new info')

WebUI.sendKeys(findTestObject('register/phone_reg'), '02742545668877')

WebUI.sendKeys(findTestObject('register/mobile_reg'), '085666544785')

WebUI.sendKeys(findTestObject('register/alias_reg'), 'alias1')

WebUI.click(findTestObject('register/btn_register_reg'))

WebUI.verifyTextPresent('MY ACCOUNT', true)

