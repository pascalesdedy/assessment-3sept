import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('http://automationpractice.com/index.php?controller=authentication&back=my-account')

WebUI.sendKeys(findTestObject('login/email_field'), 'dedy@dedy.com')

WebUI.sendKeys(findTestObject('login/passwd_field'), '123456')

WebUI.click(findTestObject('login/click_sign_in_btn'))

WebUI.click(findTestObject('purchase/click_logo'))

WebUI.click(findTestObject('purchase/select_first_item'))

WebUI.click(findTestObject('purchase/addcart1_btn'))

WebUI.clickOffset(findTestObject('purchase/checkout_popup_btn'), 0, 0)

WebUI.click(findTestObject('purchase/checkout_shopping_summary_btn'))

WebUI.click(findTestObject('purchase/checkout_address_btn'))

WebUI.click(findTestObject('purchase/click_tos'))

WebUI.click(findTestObject('purchase/checkout_shipping'))

WebUI.click(findTestObject('purchase/bankwire_payment_btn'))

WebUI.click(findTestObject('purchase/confirm_purchase_btn'))

WebUI.verifyElementText(findTestObject('purchase/verify_order_completed'), 'Your order on My Store is complete.')

